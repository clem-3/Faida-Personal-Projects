clear; close all; clc

x = [0.0 1.0 1.0 2.0 1.8 3.0 4.0 5.2 6.5 8.0 10.0]';
y = [5.00 5.04 5.12 5.28 5.48 5.72 6.00 6.32 6.68 7.08 7.52]';
n = length(x);

X = [ones(size(x)) x];
theta = X\y;                 
yhat = X*theta;
res  = y - yhat;

idx = (x==1.0);
yrep = y(idx);
sigma2 = sum((yrep-mean(yrep)).^2)/(length(yrep)-1);
C = sigma2*inv(X'*X);
SE = sqrt(diag(C));
tvals = theta./SE;

SSres = sum(res.^2);
SStot = sum((y-mean(y)).^2);
R2 = 1 - SSres/SStot;

disp('theta=[theta0 theta1]'); disp(theta');
disp('Covariance C'); disp(C);
disp('t-values'); disp(tvals');
disp(['R2=' num2str(R2)]);
xx = linspace(min(x), max(x), 200)';
yy = [ones(size(xx)) xx]*theta;

figure; plot(xx,yy,'-',x,y,'o');
grid on; xlabel('x'); ylabel('y');
legend('fit','data');
