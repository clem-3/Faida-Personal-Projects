function ds = ode(t, s, theta, T, Tref, R)

k1ref = theta(1); E1 = theta(2);
k2ref = theta(3); E2 = theta(4);

k1 = k1ref * exp((E1/R) * (1/T - 1/Tref));
k2 = k2ref * exp((E2/R) * (1/T - 1/Tref));

A = s(1); B = s(2); C = s(3); 

dA = -k1*A;
dB =  k1*A - k2*B;
dC =  k2*B;

ds = [dA; dB; dC];
end
