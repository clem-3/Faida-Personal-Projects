function lsq = Task3_lsq(theta, data282, data313, Tref, R)

% simulate 282K
[t1, s1] = ode23(@(t,s)ode(t,s,theta,282,Tref,R), data282(:,1), [1;0;0]);
A1 = s1(:,1); B1 = s1(:,2);

% simulate 313K
[t2, s2] = ode23(@(t,s)ode(t,s,theta,313,Tref,R), data313(:,1), [1;0;0]);
A2 = s2(:,1); B2 = s2(:,2);
lsq = sum((data282(:,2)-A1).^2) + sum((data282(:,3)-B1).^2) + ...
      sum((data313(:,2)-A2).^2) + sum((data313(:,3)-B2).^2);
end
