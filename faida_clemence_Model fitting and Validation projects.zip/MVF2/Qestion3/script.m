clear; close all; clc

R = 8.314;
Tref = 300;

data282 = [ ...
0 1.000 0.000
1 0.504 0.416
2 0.186 0.489
3 0.218 0.595
4 0.022 0.506
5 0.102 0.493
6 0.058 0.458
7 0.064 0.394
8 0.000 0.335
9 0.082 0.309];

data313 = [ ...
0 1.000 0.000
1 0.415 0.518
2 0.156 0.613
3 0.196 0.644
4 0.055 0.444
5 0.011 0.435
6 0.000 0.323
7 0.032 0.390
8 0.000 0.149
9 0.079 0.222];

theta0 = [1 1e4 1 1e4];   

theta_opt = fminsearch(@lsq, theta0, [], data282, data313, Tref, R);

disp('theta_opt = [k1ref E1 k2ref E2]'); disp(theta_opt);

% plot batch 282K
[t1, s1] = ode23(@(t,s)ode(t,s,theta_opt,282,Tref,R), data282(:,1), [1;0;0]);
figure; plot(t1, s1(:,1), '-', data282(:,1), data282(:,2), 'o', t1, s1(:,2), '-', data282(:,1), data282(:,3), 'o');
grid on; legend('A fit','A data','B fit','B data'); title('282K');

% plot batch 313K
[t2, s2] = ode23(@(t,s)ode(t,s,theta_opt,313,Tref,R), data313(:,1), [1;0;0]);
figure; plot(t2, s2(:,1), '-', data313(:,1), data313(:,2), 'o', t2, s2(:,2), '-', data313(:,1), data313(:,3), 'o');
grid on; legend('A fit','A data','B fit','B data'); title('313K');
