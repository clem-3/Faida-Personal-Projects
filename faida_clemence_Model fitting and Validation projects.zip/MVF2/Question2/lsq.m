function lsq = lsq(b, x, y)

% b = [b0 b1 b2] for y = exp(b0 + b1 x + b2 x^2)
y_cal = exp(b(1) + b(2)*x + b(3)*x.^2);
lsq = sum((y - y_cal).^2);
end
