clear; close all; clc

load data_8.mat   
xData = x(:);
yData = yr(:);
xGrid = linspace(min(xData), max(xData), 400)';

%Quadratic polynomial: y = a0 + a1 x + a2 x^2
p = polyfit(xData, yData, 2);          
yPolyGrid = polyval(p, xGrid);
% Positive model using exp: y = exp(b0 + b1 x + b2 x^2)
% Linearize: log(y) = b0 + b1 x + b2 x^2
X = [ones(size(xData)) xData xData.^2];
b_lsq = X \ log(yData);                 

yExpLSQGrid = exp([ones(size(xGrid)) xGrid xGrid.^2] * b_lsq);
[b_opt, ssmin] = fminsearch(@lsq, b_lsq, [], xData, yData);
yExpOptGrid = exp([ones(size(xGrid)) xGrid xGrid.^2] * b_opt);

figure;
plot(xGrid, yPolyGrid, '-', xGrid, yExpLSQGrid, '-', xGrid, yExpOptGrid, '-', xData, yData, 'o');
grid on
xlabel('x'); ylabel('y');
legend('Poly2 (polyfit)','Exp (log + \)','Exp (fminsearch)','Data','Location','best');
title(sprintf('SSE(exp fminsearch)=%.6g', ssmin));
