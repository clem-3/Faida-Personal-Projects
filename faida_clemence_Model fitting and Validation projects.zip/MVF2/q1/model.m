function T = model(t, k1, k2, T0, Ta, Tw)
Teq = (k1*Tw + k2*Ta)/(k1+k2);
T = (T0-Teq).*exp(-(k1+k2).*t) + Teq;
end
