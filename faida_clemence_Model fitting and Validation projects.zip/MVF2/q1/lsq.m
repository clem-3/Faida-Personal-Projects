function lsq = lsq(teta, T0, Ta, Tw, data)
t = data(:,1);
T_obs = data(:,2);

k1 = teta(1);
k2 = teta(2);

T_cal = model(t, k1, k2, T0, Ta, Tw);
lsq = sum((T_obs - T_cal).^2);
end
