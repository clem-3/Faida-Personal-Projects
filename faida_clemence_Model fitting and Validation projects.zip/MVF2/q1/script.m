clear; close all; clc

t_meas = [0:60:540 840 1020 1320]';
T_meas = [31 28 24 20 17.5 15.5 13.5 12 11 10 8 7 6.5]';

T0 = 31; Ta = 23; Tw = 5;

k1 = 0.001; k2 = 0.0001;
teta = [k1 k2];

data = [t_meas T_meas];

teta_opt = fminsearch(@lsq, teta, [], T0, Ta, Tw, data);

k1 = teta_opt(1); k2 = teta_opt(2);

t_new = linspace(t_meas(1), t_meas(end), 300)';
T_fit = model(t_new, k1, k2, T0, Ta, Tw);

figure;
plot(t_new, T_fit, '-', t_meas, T_meas, 'o');
grid on; xlabel('t'); ylabel('T(t)');
legend('fit','data');
