function ycal = model(theta, x)
ycal = theta(1).*x.*exp(1 + theta(2)*x.^2);
end
