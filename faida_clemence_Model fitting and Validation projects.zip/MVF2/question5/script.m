clear; close all; clc

load xy.mat          

x = xy(:,1);
y = xy(:,2);
n = length(x);

theta0 = [2 0.5];

[theta_hat, ssmin] = fminsearch(@lsq, theta0, [], x, y);

J = [ x .* exp(1 + theta_hat(2)*x.^2), ...
      theta_hat(1) .* x .* exp(1 + theta_hat(2)*x.^2) .* x.^2 ];

sigma2 = ssmin/(n-2);
C = sigma2*inv(J'*J);

disp('theta_hat = [theta1 theta2] =');
disp(theta_hat)

disp('Covariance matrix C =');
disp(C)

xfit = linspace(min(x), max(x), 300)';
yfit = model(theta_hat, xfit);

figure;
plot(xfit, yfit, '-', x, y, 'o');
grid on
xlabel('x'); ylabel('y');
legend('fit','data');
title('nonlinear fit');
