function lsq = lsq(theta, x, y)
ycal = model(theta, x);
lsq = sum((y - ycal).^2);
end

